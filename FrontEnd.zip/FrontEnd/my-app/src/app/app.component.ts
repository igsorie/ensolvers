import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Ensolvers';
  constructor(private http:HttpClient)
  {
    this.loadFolders();
  }
folders: any[] = [];
  loadFolders()
  {
    this.http.get('https://localhost:8443/folders/')
    .subscribe((folders: any) => {
        this.folders = folders;
    });
  }
  items: any[] = [];

  viewItems(id:number)
  {
    this.http.get('https://localhost:8443/items/'+ '/' + id)
    .subscribe((items: any) => {
        this.items = items;
    });
  }
  
  addFolder(item:string)
  {
    const body = { name: item };
    this.http.post('https://localhost:8443/folders/', body).
    subscribe((response)=>{alert(JSON.stringify(response))});
    this.refresh();
  }

  removeFolder(id:number)
  {
    this.http.delete('https://localhost:8443/folders' + '/' + id)
    .subscribe((response)=>{alert(JSON.stringify(response))});;
    this.refresh();
  }

  refresh(): void {
    window.location.reload();
}

}
